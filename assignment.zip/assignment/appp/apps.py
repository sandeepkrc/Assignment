from django.apps import AppConfig


class ApppConfig(AppConfig):
    name = 'appp'
