from django import forms
class StudentM(forms.Form):
     Name = forms.CharField(max_length=20)
     Roll_No = forms.IntegerField()
     Marks_In_Maths = forms.IntegerField()
     Marks_In_Phy = forms.IntegerField()
     Marks_In_Che = forms.IntegerField()
     #Totalf= forms.IntegerField()
     #Percentagef= forms.IntegerField()