from django.shortcuts import render
from django.http import HttpResponse
from .forms import StudentM
from .models import NameModel

def page1(request):
    return render(request,"page1.html")
def input(request):
    sm=StudentM()
    return render(request,"page2.html",{'form':sm})
def insert(request):
    if request.method == 'POST':
        Name=request.POST["Name"]
        Roll_No=request.POST["Roll_No"]
        Marks_Maths=request.POST["Marks_In_Maths"]
        Marks_Phy=request.POST["Marks_In_Phy"]
        Marks_Che=request.POST["Marks_In_Che"]
        # Total=request.POST["Totalf"]
        # Percentage=request.POST["Percentagef"]
        NameModel2=NameModel(Name=Name,
                         Roll_No=Roll_No,
                         Marks_Maths=Marks_Maths,
                         Marks_Che=Marks_Che,
                         Marks_Phy=Marks_Phy)
        NameModel2.save()
        data = NameModel.objects.all().order_by("Roll_No")
        # stu = {
        #     "student_number": data
        #     }
        
        # return render(request,"display.html",stu)
        return render(request,"submit.html")
    else:
        sm=StudentM()
        return render(request,"page2.html",{'form':sm})
def display(request):
    data = NameModel.objects.all()
    stu = {
        "student_number": data
        }
    return render(request,"display.html",stu)

def percentage_calculate(request):
    x=request.POST["Marks_In_Maths"]
    y=request.POST["Marks_In_Phy"]
    z=request.POST["Marks_In_Che"]
    z1=(int(x)+int(y)+int(z))//3
    dict1={
        'keys': z1
    }
    return render(request,"percentage.hml",dict1)
    




